// CONTACT BUTTON SCROLL
const contactButton = document.getElementById("contactButton");
if (contactButton) {
  contactButton.addEventListener("click", () => {
    document.getElementById("contact").scrollIntoView({
      behavior: "smooth",
    });
  });
}

// FOTO ZOOM
const foto = document.querySelector(".profile-img");
if (foto) {
  foto.addEventListener("click", () => {
    foto.classList.toggle("active");
  });
}

// TYPING EFFECT
const typingEl = document.getElementById("typing");
const text = "Welcome to my website";
let index = 0;

function typingEffect() {
  if (typingEl && index < text.length) {
    typingEl.innerHTML += text.charAt(index);
    index++;
    setTimeout(typingEffect, 80);
  }
}
typingEffect();

// FORM SUBMIT (FORMSPREE)
const form = document.getElementById("contactForm");
const status = document.getElementById("formStatus");

if (form) {
  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    status.textContent = "Mengirim pesan...";
    
    const response = await fetch(form.action, {
      method: form.method,
      body: new FormData(form),
      headers: { Accept: "application/json" },
    });
    
    if (response.ok) {
      status.textContent = "Pesan berhasil dikirim ✅";
      form.reset();
    } else {
      status.textContent = "Gagal mengirim pesan ❌";
    }
  });
}

// SCROLL REVEAL
const reveals = document.querySelectorAll(".reveal");
window.addEventListener("scroll", () => {
  reveals.forEach(el => {
    const top = el.getBoundingClientRect().top;
    if (top < window.innerHeight - 100) {
      el.classList.add("active");
    }
  });
});

// AUTO YEAR
document.getElementById("year").textContent = new Date().getFullYear();